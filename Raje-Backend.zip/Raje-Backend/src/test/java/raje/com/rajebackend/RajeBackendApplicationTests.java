package raje.com.rajebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RajeBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
