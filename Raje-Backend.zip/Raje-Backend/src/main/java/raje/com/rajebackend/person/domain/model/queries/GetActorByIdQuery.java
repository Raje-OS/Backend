package raje.com.rajebackend.person.domain.model.queries;

public record GetActorByIdQuery(String id) {}
