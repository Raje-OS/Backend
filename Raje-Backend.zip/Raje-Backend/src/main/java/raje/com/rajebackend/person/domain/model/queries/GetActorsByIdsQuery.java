package raje.com.rajebackend.person.domain.model.queries;

import java.util.List;

public record GetActorsByIdsQuery(List<String> ids) {}
